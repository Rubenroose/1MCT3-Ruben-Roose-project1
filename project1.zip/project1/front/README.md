# HTML5 boilerplate
This is my HTML5 boilerplate. I use it to build fast, robust, and adaptable web apps or sites.
